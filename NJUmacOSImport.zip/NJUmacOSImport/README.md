# 南京大学课表 → macOS SwiftUI / AppKit 导入模块

这是一组可以拷贝到**已有的 macOS 原生 App**里的源文件（不是完整 `.xcodeproj`）。

## 包含内容

- `Sources/NJUModels.swift`：Codable 课程模型；正确处理 `weeks`、`week_time`、`start_time`、`time_count`。
- `Sources/NJUWebImporter.swift`：WKWebView 会话、官方登录页、运行本地 JavaScript、JSON 解码、经用户确认后保存。
- `Sources/NJUImportView.swift`：SwiftUI 的 `NSViewRepresentable` 包装器和课表导入 UI。
- `Resources/njubksjw2.js`：从南哪课表开源仓库引用的本科教务解析器。
- `Resources/njuyjsjw.js`：从南哪课表开源仓库引用的研究生教务解析器。
- `THIRD_PARTY_APACHE_LICENSE.txt`：对应第三方解析器的 Apache-2.0 许可证。

## 如何集成

1. 在 Xcode macOS App Target（建议 macOS 13+，Swift 5.9+）中加入 `Sources/*.swift`。
2. 在 Xcode 将 `Resources/*.js` 拖入工程，勾选你的 App Target，确认它们出现在 **Build Phases → Copy Bundle Resources**。使用 `Bundle.main.url(forResource:withExtension:)` 加载，绝不从 CDN 动态下载 JS。
3. 在你的主界面、单独 WindowGroup 或 sheet 中插入 `NJUImportView()`。例如：

   ```swift
   import SwiftUI

   struct ContentView: View {
       var body: some View {
           NJUImportView()
               .frame(minWidth: 850, minHeight: 700)
       }
   }
   ```

4. 若开启 **App Sandbox**，在 **Signing & Capabilities → App Sandbox** 中开启 **Outgoing Connections (Client)**（网络客户端权限）。
5. 运行 App：选择本科/研究生教务 → 在学校官方网页完成登录 → 确保打开课表 → 点击「导入当前课表」→ **核对学期** → 点击「确认学期并保存」。
6. 默认生成 `Application Support/<你的 Bundle ID>/nju_<source>_<semester>.json`。如果已有 SwiftData/Core Data 数据层，可将 `NJUWebImporter` 中 `saveLocally` 替换为你的持久化方法。

## 字段与数据处理

解析器的返回值是 `encodeURIComponent(JSON.stringify({ name, courses }))`。

- 需先 `removingPercentEncoding`，再交给 `JSONDecoder`。
- **`weeks`** 是上课周次数组；本项目两份源码实际使用 `weeks`，虽然 README 示例曾写 `week`。
- `week_time`: 1~7 代表周一至周日，0 代表自由时间。部分异常数据可能缺失该字段。
- `start_time`: 起始节次（从 1 开始）；`time_count`: `末节编号 - 首节编号`，因此 3-4 节对应 `time_count = 1`。要算实际节数须 `time_count + 1`。
- 同一门课程可能出现不同周次、教室、时段的多条记录；请勿简单以课程名称去重。
- 生成真实日期时间还需要独立的「学期第 1 周周一日期」与「每节课起止时间表」，示例故意不伪造这两份数据。

## 适配限制（重要）

- **本科**：脚本依赖 `#dqxnxqkclb` 和页面表格 DOM；若学校改版，需要更新解析器。要先在页面进入有课程数据的课表视图再导入。
- **研究生**：来源脚本使用同步 `XMLHttpRequest`，并 `terms.sort(...); currentTerm = terms[0]` 选取学期，**不保证选的是当前学期**。此示例的预览和人工确认可防止静默存入错误学期。正式发布前建议重构为异步请求与明确的学期 Picker。
- 登录可能需要校园 VPN 或官方网络环境；WKWebView 的非持久化 Cookie 不会沿用 Safari 已登录状态。
- 未经真实南京大学教务账号及实际 macOS Xcode 构建环境做端到端验收；只对打包文件进行了语法与模拟解析验证。

## 安全与授权

- 只在 `https://ehallapp.nju.edu.cn` 的相应教务系统路径上执行**随 App 打包**的 JS；其他网页不会触发解析。
- 默认使用 `WKWebsiteDataStore.nonPersistent()`；App 不收集用户名和密码，不上传 Cookie。
- 保存的 JSON 包含个人课程信息，请按敏感本地数据处理；如需 iCloud 同步，征得用户同意。
- 解析脚本来源： https://github.com/WheretoSleepinNJU/NJU-Class-Shedule-Flutter/tree/master/api/tools （Apache-2.0）。保留授权文件、原作者署名和必要 NOTICE；如果修改原解析脚本，应显著标注改动。

源码参考：
- https://github.com/WheretoSleepinNJU/NJU-Class-Shedule-Flutter/blob/master/api/schoolList.json
- https://github.com/WheretoSleepinNJU/NJU-Class-Shedule-Flutter/blob/master/api/tools/njubksjw2.js
- https://github.com/WheretoSleepinNJU/NJU-Class-Shedule-Flutter/blob/master/api/tools/njuyjsjw.js
- https://developer.apple.com/documentation/webkit/wkwebview
