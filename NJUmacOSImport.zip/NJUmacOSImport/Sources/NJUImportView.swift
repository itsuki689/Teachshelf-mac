import SwiftUI
import WebKit

struct NJULoginWebView: NSViewRepresentable {
    let webView: WKWebView

    func makeNSView(context: Context) -> WKWebView { webView }
    func updateNSView(_ nsView: WKWebView, context: Context) { }
}

/// Drop this View inside a WindowGroup, sheet, or existing macOS window.
struct NJUImportView: View {
    @StateObject private var importer = NJUWebImporter()
    @State private var selectedSource: NJUSource = .undergraduate

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Picker("教务系统", selection: $selectedSource) {
                    ForEach(NJUSource.allCases) { source in
                        Text(source.title).tag(source)
                    }
                }
                .frame(width: 240)

                Button("重新打开登录页") {
                    importer.open(selectedSource)
                }
                Button("导入当前课表") {
                    importer.importCurrentSchedule()
                }
                Spacer()
            }
            .padding(12)

            NJULoginWebView(webView: importer.webView)
                .frame(minWidth: 720, minHeight: 400)

            Divider()
            VStack(alignment: .leading, spacing: 8) {
                Text(importer.status)
                    .font(.callout)
                    .textSelection(.enabled)

                if let schedule = importer.schedule {
                    HStack {
                        Text("\(schedule.name) · 共 \(schedule.courses.count) 条课程时段")
                            .font(.headline)
                        Spacer()
                        Button("确认学期并保存") {
                            importer.confirmAndSave()
                        }
                    }

                    List(schedule.courses) { course in
                        HStack {
                            Text(course.name)
                            Spacer()
                            Text(course.displayPeriod)
                                .foregroundStyle(.secondary)
                            Text(course.classroom ?? "")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(height: 160)

                    if let file = importer.savedFileURL {
                        Text("本地文件：\(file.path)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                }
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .onChange(of: selectedSource) { newValue in
            importer.open(newValue)
        }
    }
}
