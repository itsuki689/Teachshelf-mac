import Foundation

/// The JSON contract returned by the Nan-Na timetable parser scripts.
struct NJUSchedule: Codable {
    let name: String
    let courses: [NJUCourse]
}

struct NJUCourse: Codable, Identifiable {
    let name: String
    let classroom: String?
    let classNumber: String?
    let teacher: String?
    let weeks: [Int]
    let weekday: Int?          // 1 = Monday; 7 = Sunday; 0 = free-time item
    let startSection: Int      // 1-based; 0 = free-time item
    let timeCount: Int         // Last section index - first section index
    let examTime: String?
    let examLocation: String?
    let info: String?

    /// e.g. 3-4节 has timeCount == 1 and endSection == 4.
    var endSection: Int { startSection + timeCount }
    var sectionCount: Int { startSection > 0 ? timeCount + 1 : 0 }

    var displayPeriod: String {
        guard let weekday, (1...7).contains(weekday), startSection > 0 else {
            return "自由时间"
        }
        return "周\(weekday) · \(startSection)-\(endSection)节"
    }

    // Stable enough for a preview list; use a real database key for your own schema.
    var id: String {
        [name,
         classNumber ?? "",
         classroom ?? "",
         String(weekday ?? 0),
         String(startSection),
         String(timeCount),
         weeks.sorted().map(String.init).joined(separator: ",")]
            .joined(separator: "|")
    }

    enum CodingKeys: String, CodingKey {
        case name, classroom, teacher, weeks, info
        case classNumber = "class_number"
        case weekday = "week_time"
        case startSection = "start_time"
        case timeCount = "time_count"
        case examTime = "test_time"
        case examLocation = "test_location"
    }
}
