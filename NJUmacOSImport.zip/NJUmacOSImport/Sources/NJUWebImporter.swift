import Foundation
import SwiftUI
import WebKit

enum NJUSource: String, CaseIterable, Identifiable {
    case undergraduate
    case graduate

    var id: String { rawValue }
    var title: String {
        switch self {
        case .undergraduate: return "本科生教务系统"
        case .graduate: return "研究生教务系统"
        }
    }

    var parserFile: String {
        switch self {
        case .undergraduate: return "njubksjw2"
        case .graduate: return "njuyjsjw"
        }
    }

    /// Login URLs as advertised by the source project's schoolList.json.
    var loginURL: URL {
        let address: String
        switch self {
        case .undergraduate:
            address = "https://authserver.nju.edu.cn/authserver/login?service=https%3A%2F%2Fehallapp.nju.edu.cn%2Fjwapp%2Fsys%2Fwdkb%2F*default%2Findex.do%23%2Fxskcb"
        case .graduate:
            address = "https://authserver.nju.edu.cn/authserver/login?service=https%3A%2F%2Fehallapp.nju.edu.cn%2Fgsapp%2Fsys%2Fwdkbapp%2F*default%2Findex.do%23%2Fxskcb"
        }
        return URL(string: address)!
    }

    var expectedPathPrefix: String {
        switch self {
        case .undergraduate: return "/jwapp/sys/wdkb/"
        case .graduate: return "/gsapp/sys/wdkbapp/"
        }
    }

    var readinessProbe: String {
        switch self {
        case .undergraduate:
            return "Boolean(document.querySelector('#dqxnxqkclb') && document.querySelector('table tbody tr'))"
        case .graduate:
            return "document.readyState !== 'loading'"
        }
    }
}

/// State + WebKit session for a single timetable-import dialog.
/// Nonpersistent cookies are shared within this WKWebView session only.
@MainActor
final class NJUWebImporter: ObservableObject {
    @Published private(set) var status = "请通过学校官方页面登录，进入课表后点击「导入当前课表」。"
    @Published private(set) var schedule: NJUSchedule?
    @Published private(set) var savedFileURL: URL?
    @Published private(set) var source: NJUSource = .undergraduate

    let webView: WKWebView

    init() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        webView = WKWebView(frame: .zero, configuration: config)
        webView.load(URLRequest(url: NJUSource.undergraduate.loginURL))
    }

    func open(_ newSource: NJUSource) {
        source = newSource
        schedule = nil
        savedFileURL = nil
        status = "正在打开\(newSource.title)。请登录并进入课表页面。"
        webView.stopLoading()
        webView.load(URLRequest(url: newSource.loginURL))
    }

    func importCurrentSchedule() {
        guard let url = webView.url,
              url.scheme?.lowercased() == "https",
              url.host?.lowercased() == "ehallapp.nju.edu.cn",
              url.path.hasPrefix(source.expectedPathPrefix) else {
            status = "尚未进入对应的教务课表页面，请先完成学校登录并打开课表。"
            return
        }

        guard let scriptURL = Bundle.main.url(forResource: source.parserFile, withExtension: "js"),
              let script = try? String(contentsOf: scriptURL, encoding: .utf8) else {
            status = "解析脚本未打包：请将 \(source.parserFile).js 加入 App Target 的 Copy Bundle Resources。"
            return
        }

        status = "正在检查课表是否已加载……"
        webView.evaluateJavaScript(source.readinessProbe) { [weak self] raw, error in
            guard let self else { return }
            guard error == nil, (raw as? Bool) == true else {
                self.status = "课表尚未加载完成，请在网页中打开课表后重试。"
                return
            }
            self.evaluateParser(script)
        }
    }

    private func evaluateParser(_ script: String) {
        status = "正在从学校页面解析课表……"
        webView.evaluateJavaScript(script) { [weak self] value, error in
            guard let self else { return }

            if let error {
                self.status = "解析脚本执行失败：\(error.localizedDescription)"
                return
            }
            guard let encoded = value as? String,
                  let json = encoded.removingPercentEncoding,
                  let data = json.data(using: .utf8) else {
                self.status = "解析器没有返回预期的 URL 编码 JSON。"
                return
            }

            do {
                let imported = try JSONDecoder().decode(NJUSchedule.self, from: data)
                guard !imported.name.isEmpty, !imported.courses.isEmpty else {
                    self.status = "未获取到课程，请确认学期与课表内容后重试。"
                    return
                }
                self.schedule = imported
                self.savedFileURL = nil
                self.status = "已解析 \(imported.courses.count) 条课程时段。请核对学期「\(imported.name)」，然后确认保存。"
            } catch {
                self.status = "课表解码或存储失败：\(error.localizedDescription)"
            }
        }
    }

    func confirmAndSave() {
        guard let schedule else {
            status = "请先读取课程表。"
            return
        }
        do {
            savedFileURL = try Self.saveLocally(schedule, from: source)
            status = "已保存学期「\(schedule.name)」的 \(schedule.courses.count) 条课程时段。"
        } catch {
            status = "保存失败：\(error.localizedDescription)"
        }
    }

    private static func saveLocally(_ schedule: NJUSchedule, from source: NJUSource) throws -> URL {
        let manager = FileManager.default
        let appSupport = manager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let root = appSupport.appendingPathComponent(
            Bundle.main.bundleIdentifier ?? "NJUCourseImporter",
            isDirectory: true
        )
        try manager.createDirectory(at: root, withIntermediateDirectories: true)

        let cleanTerm = schedule.name.replacingOccurrences(
            of: #"[^\p{L}\p{N}._-]+"#,
            with: "_",
            options: .regularExpression
        )
        let fileName = "nju_\(source.rawValue)_\(String(cleanTerm.prefix(80))).json"
        let target = root.appendingPathComponent(fileName)

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(schedule).write(to: target, options: .atomic)
        return target
    }
}
